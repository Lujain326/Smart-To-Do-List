#include "LinkedList.h"
#include "Colors.h"
#include <iostream>
using namespace std;

LinkedList::LinkedList(){ head=NULL; }

void LinkedList::insert(Task t){
    Node* n=new Node{t,NULL};
    if(!head){ head=n; return; }
    Node* temp=head;
    while(temp->next) temp=temp->next;
    temp->next=n;
}

bool LinkedList::search(string name){
    Node* temp=head;
    while(temp){
        if(temp->task.name==name) return true;
        temp=temp->next;
    }
    return false;
}

bool LinkedList::priorityExists(int p){
    Node* temp=head;
    while(temp){
        if(temp->task.priority==p) return true;
        temp=temp->next;
    }
    return false;
}
bool LinkedList::remove(string name){
    Node* temp=head; Node* prev=NULL;
    while(temp){
        if(temp->task.name==name){
            if(prev) prev->next=temp->next;
            else head=temp->next;
            delete temp;
            return true;
        }
        prev=temp; temp=temp->next;
    }
    return false;
}

void LinkedList::displayFIFO(){
    if(!head){ cout<<RED<<"No tasks\n"<<RESET; return; }
    Node* temp=head;
    while(temp){
        cout<<CYAN<<temp->task.name<<" ("<<temp->task.priority<<")\n"<<RESET;
        temp=temp->next;
    }
}
