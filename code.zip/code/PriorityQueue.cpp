#include "PriorityQueue.h"
#include "Colors.h"
#include <iostream>
using namespace std;

PriorityQueue::PriorityQueue(){ size=0; }

void PriorityQueue::heapifyUp(int i){
    while(i>0){
        int p=(i-1)/2;
        if(heap[p].priority<=heap[i].priority) break;
        swap(heap[p],heap[i]);
        i=p;
    }
}

void PriorityQueue::heapifyDown(int i){
    while(true){
        int l=2*i+1,r=2*i+2,small=i;
        if(l<size && heap[l].priority<heap[small].priority) small=l;
        if(r<size && heap[r].priority<heap[small].priority) small=r;
        if(small==i) break;
        swap(heap[i],heap[small]);
        i=small;
    }
}

void PriorityQueue::push(Task t){ heap[size]=t; heapifyUp(size++); }
Task PriorityQueue::pop(){ Task r=heap[0]; heap[0]=heap[--size]; heapifyDown(0); return r; }

bool PriorityQueue::isEmpty(){ return size==0; }

void PriorityQueue::sortDisplay(){
    if(size==0){ cout<<RED<<"No tasks\n"<<RESET; return; }

    Task temp[100]; int n=size;
    for(int i=0;i<n;i++) temp[i]=heap[i];

    // simple selection sort (stable, no duplicates issue)
    for(int i=0;i<n-1;i++){
        int min=i;
        for(int j=i+1;j<n;j++)
            if(temp[j].priority<temp[min].priority)
                min=j;
        swap(temp[i],temp[min]);
    }

    cout<<GREEN<<"Sorted (Ascending):\n"<<RESET;
    for(int i=0;i<n;i++)
        cout<<YELLOW<<temp[i].name<<" ("<<temp[i].priority<<")\n"<<RESET;
}
