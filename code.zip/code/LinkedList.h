
#ifndef LINKEDLIST_H
#define LINKEDLIST_H
#include "Task.h"
struct Node { Task task; Node* next; };
class LinkedList {
public:
    Node* head;
    LinkedList();
    void insert(Task t);
    bool search(string name);
    bool remove(string name);
    bool priorityExists(int p);
    void displayFIFO();
};
#endif
