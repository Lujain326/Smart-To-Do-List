#include "Stack.h"
Stack::Stack(){ top=-1; }
void Stack::push(Task t){ arr[++top]=t; }
Task Stack::pop(){ return arr[top--]; }
bool Stack::isEmpty(){ return top==-1; }
