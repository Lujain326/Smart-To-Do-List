#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "FileManager.h"
#include <QMessageBox>
#include <QInputDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 1. Load tasks from file into the priority queue on startup
    FileManager::load(pq);

    // 2. Also populate your linked list from the loaded queue so they sync
    // (Since your heap array is public, we can read directly from it)
    for(int i = 0; i < pq.size; i++) {
        list.insert(pq.heap[i]);
    }

    // 3. Draw them on the screen
    updateVisuals();
}

MainWindow::~MainWindow()
{
    // Save data automatically when the user closes the app window
    FileManager::save(pq);
    delete ui;
}

// Helper function to sync your LinkedList data with the visual screen
void MainWindow::updateVisuals()
{
    ui->taskListDisplay->clear();
    Node* temp = list.head;
    while(temp) {
        QString itemText = QString::fromStdString(temp->task.name) + " (Priority: " + QString::number(temp->task.priority) + ")";
        ui->taskListDisplay->addItem(itemText);
        temp = temp->next;
    }
}

// 1. ADD TASK BUTTON
void MainWindow::on_addButton_clicked()
{
    std::string name = ui->taskInput->text().toStdString();
    int priority = ui->priorityInput->value();

    if(name.empty()) {
        QMessageBox::warning(this, "Input Error", "Task name cannot be empty!");
        return;
    }

    if(list.priorityExists(priority)) {
        QMessageBox::critical(this, "Duplicate Priority", "This priority already exists! Choose another.");
        return;
    }

    Task t{name, priority};
    pq.push(t);
    list.insert(t);

    ui->taskInput->clear();
    updateVisuals();
}

// 2. COMPLETE TASK BUTTON
void MainWindow::on_completeButton_clicked()
{
    if(pq.isEmpty()) {
        QMessageBox::information(this, "Status", "No tasks left to complete!");
        return;
    }

    Task d = pq.pop();
    list.remove(d.name);
    undo.push(d);

    QMessageBox::information(this, "Success", QString::fromStdString(d.name) + " marked as completed!");
    updateVisuals();
}

// 3. UNDO BUTTON
void MainWindow::on_undoButton_clicked()
{
    if(undo.isEmpty()) {
        QMessageBox::warning(this, "Undo Error", "Nothing to undo!");
        return;
    }

    // Modern trick: Ask for the task name via a pop-up input dialog box
    bool ok;
    QString text = QInputDialog::getText(this, "Undo Task", "Enter name of completed task to restore:", QLineEdit::Normal, "", &ok);

    if (!ok || text.isEmpty()) return;
    std::string name = text.toStdString();

    Stack temp;
    bool found = false;

    while(!undo.isEmpty()){
        Task t = undo.pop();
        if(t.name == name && !found){
            found = true;

            // Ask for a new priority level dynamically
            int pr = QInputDialog::getInt(this, "New Priority", "Enter new priority for " + text + ":", 1, 1, 10, 1, &ok);

            while(list.priorityExists(pr)) {
                QMessageBox::warning(this, "Error", "Priority exists! Choose a unique number.");
                pr = QInputDialog::getInt(this, "New Priority", "Enter new priority:", 1, 1, 10, 1, &ok);
            }

            Task nt{name, pr};
            pq.push(nt);
            list.insert(nt);
        } else {
            temp.push(t);
        }
    }
    while(!temp.isEmpty()) undo.push(temp.pop());

    if(found) {
        QMessageBox::information(this, "Restored", "Task successfully restored!");
        updateVisuals();
    } else {
        QMessageBox::critical(this, "Not Found", "That task was not found in your completed history.");
    }
}

// 4. SORT BY PRIORITY BUTTON
void MainWindow::on_sortButton_clicked()
{
    if(pq.isEmpty()) {
        QMessageBox::information(this, "Status", "No tasks to sort.");
        return;
    }

    // Clean visualization of your exact selection sort backend logic
    ui->taskListDisplay->clear();
    Task temp[100];
    int n = pq.size;
    for(int i = 0; i < n; i++) temp[i] = pq.heap[i];

    for(int i = 0; i < n - 1; i++){
        int min = i;
        for(int j = i + 1; j < n; j++)
            if(temp[j].priority < temp[min].priority) min = j;
        std::swap(temp[i], temp[min]);
    }

    for(int i = 0; i < n; i++) {
        QString itemText = QString::fromStdString(temp[i].name) + " (Priority: " + QString::number(temp[i].priority) + ") [SORTED]";
        ui->taskListDisplay->addItem(itemText);
    }
}
void MainWindow::on_pushButton_clicked()
{
    bool ok;
    QString searchName = QInputDialog::getText(this, tr("Search Task"),
                                               tr("Enter the name of the task:"), QLineEdit::Normal,
                                               "", &ok);

    if (ok && !searchName.isEmpty()) {

        QList<QListWidgetItem *> foundItems = ui->taskListDisplay->findItems(searchName, Qt::MatchContains);

        if (!foundItems.isEmpty()) {

            ui->taskListDisplay->setCurrentItem(foundItems.first());
        } else {

            QMessageBox::warning(this, "Not Found", "That task is not in the list!");
        }
    }
}

