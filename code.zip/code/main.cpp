#include "mainwindow.h"
#include <QApplication>
#include <QStyleFactory>
#include <QIcon> // 1. Add this include

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    a.setStyle(QStyleFactory::create("Fusion"));

    // 2. Add this line to set the window icon
    a.setWindowIcon(QIcon("logo.ico"));

    MainWindow w;
    w.show();

    return a.exec();
}