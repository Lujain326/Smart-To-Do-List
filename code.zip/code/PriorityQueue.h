#ifndef PRIORITYQUEUE_H
#define PRIORITYQUEUE_H
#include "Task.h"
class PriorityQueue{
public:
    Task heap[100]; int size;
    PriorityQueue();
    void heapifyUp(int);
    void heapifyDown(int);
    void push(Task);
    Task pop();
    bool isEmpty();
    void sortDisplay();
};
#endif
