#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "PriorityQueue.h"
#include "LinkedList.h"
#include "Stack.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // These match the buttons you created in the UI designer
    void on_addButton_clicked();
    void on_completeButton_clicked();
    void on_undoButton_clicked();
    void on_sortButton_clicked();

    void on_pushButton_clicked();

private:
    Ui::MainWindow *ui;

    // Your backend data structures live here now!
    PriorityQueue pq;
    LinkedList list;
    Stack undo;

    // Helper function to keep the screen updated
    void updateVisuals();
};
#endif // MAINWINDOW_H