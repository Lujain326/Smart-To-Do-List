#ifndef FILEMANAGER_H
#define FILEMANAGER_H
#include "PriorityQueue.h"
class FileManager{ public: static void save(PriorityQueue&); static void load(PriorityQueue&); };
#endif

