#include <fstream>
#include "FileManager.h"

using namespace std;

void FileManager::save(PriorityQueue &pq){
    ofstream f("tasks.txt");
    for(int i=0;i<pq.size;i++) f<<pq.heap[i].name<<" "<<pq.heap[i].priority<<"\n";
}


void FileManager::load(PriorityQueue &pq) {
    // CLEAR FILE ON START (fresh session)
    ofstream clear("tasks.txt", ios::trunc);
    clear.close();
}
