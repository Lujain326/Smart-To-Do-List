#ifndef STACK_H
#define STACK_H
#include "Task.h"
class Stack{
    Task arr[100]; int top;
public:
    Stack(); void push(Task); Task pop(); bool isEmpty();
};
#endif

// Stack.cpp
