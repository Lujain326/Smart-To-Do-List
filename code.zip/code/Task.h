#ifndef TASK_H
#define TASK_H
#include <string>
using namespace std;
struct Task { string name; int priority; };
#endif